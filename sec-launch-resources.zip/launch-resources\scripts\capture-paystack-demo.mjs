/**
 * Record a Paystack ticket-purchase demo for activation review.
 *
 * Usage (from sec-night-life/):
 *   npm run launch:paystack-demo
 *
 * 1. Log in as Party-Goer when prompted.
 * 2. Script navigates to an event with tickets.
 * 3. Complete Paystack test checkout manually (card 4084084084084081).
 * 4. Press ENTER when ticket appears in Profile → Tickets.
 */
import { createRequire } from 'module';
import { mkdirSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { PRODUCTION_URL, VIEWPORT, DEVICE_SCALE_FACTOR } from './capture-routes.mjs';
import {
  waitForManualLogin,
  gotoAuthenticated,
  resolveEventDetailsPath,
  waitForEnter,
  finalizeVideo,
} from './capture-helpers.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(join(__dirname, '../../sec-night-life/package.json'));
const { chromium } = require('playwright');

const KIT_ROOT = join(__dirname, '..');
const BASE_URL = (process.env.BASE_URL || PRODUCTION_URL).replace(/\/+$/, '');
const OUTPUT_MP4 = join(KIT_ROOT, 'paystack/payment-demo-ticket.mp4');
const CONTINUE_PARTY = join(__dirname, '.continue-party');

async function resolveEventWithTickets(page) {
  const eventPath = await page.evaluate(async () => {
    const token = localStorage.getItem('access_token') || sessionStorage.getItem('access_token');
    if (!token) return null;
    const res = await fetch('/api/events?limit=20', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    const data = await res.json();
    const list = Array.isArray(data) ? data : data?.events ?? data?.items ?? [];
    for (const ev of list) {
      const tiers = ev.ticket_tiers ?? ev.ticketTiers ?? [];
      if (tiers.length > 0 && ev.id) return `/EventDetails?id=${ev.id}`;
    }
    if (list[0]?.id) return `/EventDetails?id=${list[0].id}`;
    return null;
  });
  return eventPath || (await resolveEventDetailsPath(page));
}

async function main() {
  mkdirSync(dirname(OUTPUT_MP4), { recursive: true });

  console.log(`\nSEC Paystack Demo Recorder — ${BASE_URL}`);
  console.log('Records ticket purchase flow for Paystack activation review.\n');

  const browser = await chromium.launch({ headless: false, slowMo: 80 });
  const context = await browser.newContext({
    viewport: VIEWPORT,
    deviceScaleFactor: DEVICE_SCALE_FACTOR,
    colorScheme: 'dark',
    recordVideo: { dir: dirname(OUTPUT_MP4), size: VIEWPORT },
  });
  const page = await context.newPage();

  try {
    await waitForManualLogin(page, BASE_URL, {
      roleIntent: 'PARTY_GOER',
      continueFile: CONTINUE_PARTY,
      instructions: [
        'PAYSTACK DEMO — PARTY-GOER',
        '1. Sign in with your Party-Goer account.',
        '2. Stay in Party Goer mode.',
        '3. Wait until Home loads, then capture continues automatically.',
      ].join('\n'),
    });

    const eventPath = await resolveEventWithTickets(page);
    console.log(`\nNavigating to event: ${eventPath}`);
    await gotoAuthenticated(page, BASE_URL, eventPath, { file: 'event-details' });

    console.log('\n' + '='.repeat(64));
    console.log('MANUAL STEPS (recorded):');
    console.log('1. Select a ticket tier and quantity.');
    console.log('2. Tap Buy / Pay — complete Paystack checkout.');
    console.log('   Test card: 4084084084084081, expiry any future date, CVV 408');
    console.log('3. After success, open Profile → Tickets and show your QR ticket.');
    console.log('4. Press ENTER here when finished.');
    console.log('='.repeat(64) + '\n');

    await waitForEnter('Press ENTER when demo is complete (ticket visible in Profile)... ', null);

    await page.waitForTimeout(1500);
  } finally {
    const video = page.video();
    await context.close();
    await browser.close();
    if (video) {
      const webmPath = await video.path();
      finalizeVideo(webmPath, OUTPUT_MP4, KIT_ROOT);
      console.log('\n✓ Paystack demo saved:', OUTPUT_MP4);
    }
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
