# SEC Nightlife — Legal Document URLs

Use these URLs in App Store Connect and Google Play Console.

**Production app:** https://sec-nightlife.vercel.app

> Update to `https://secnightlife.com` (or your custom domain) when DNS is connected.

## Required for store listings

| Document | URL |
|----------|-----|
| Privacy Policy | https://sec-nightlife.vercel.app/PrivacyPolicy |
| Terms of Service | https://sec-nightlife.vercel.app/TermsOfService |

## All legal documents (Settings → Support)

| Document | URL | Local export |
|----------|-----|--------------|
| User Agreement | https://sec-nightlife.vercel.app/UserAgreement | documents/user-agreement.png |
| Terms of Service | https://sec-nightlife.vercel.app/TermsOfService | documents/terms-of-service.png |
| Privacy Policy | https://sec-nightlife.vercel.app/PrivacyPolicy | documents/privacy-policy.png |
| Community Guidelines | https://sec-nightlife.vercel.app/CommunityGuidelines | documents/community-guidelines.png |
| GBV Consequences | https://sec-nightlife.vercel.app/GbvConsequences | documents/gbv-consequences.png |
| Refund Policy | https://sec-nightlife.vercel.app/RefundPolicy | documents/refund-policy.png |
| Venue Compliance Charter | https://sec-nightlife.vercel.app/VenueComplianceCharter | documents/venue-compliance-charter.png |
| Promoter Code of Conduct | https://sec-nightlife.vercel.app/PromoterCodeOfConduct | documents/promoter-code-of-conduct.png |
| Age Verification Declaration | https://sec-nightlife.vercel.app/AgeVerificationDeclaration | documents/age-verification-declaration.png |

## Support

- In-app: Settings → Help Center
- App: https://sec-nightlife.vercel.app/Settings
